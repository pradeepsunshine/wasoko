<?php
declare(strict_types=1);

namespace Wasoko\Creditmemo\Rewrite\Magento\Ui\Model\Export;

use Magento\Framework\Api\Search\DocumentInterface;

class MetadataProvider extends \Magento\Ui\Model\Export\MetadataProvider
{
    /**
     * Returns row data
     *
     * @param DocumentInterface $document
     * @param array $fields
     * @param array $options
     *
     * @return string[]
     */
    public function getRowData(DocumentInterface $document, $fields, $options): array
    {
        $row = [];
        foreach ($fields as $column) {
            if (isset($options[$column])) {
                $key = $document->getCustomAttribute($column)->getValue();
                if (isset($options[$column][$key])) {
                    $row[] = $options[$column][$key];
                } else {
                    $row[] = $key;
                }
            } else {
                $value = $document->getCustomAttribute($column)->getValue();
                if (in_array('creditmemo_dummy_field', $fields)) {
                    if ($column == 'base_price' || $column == 'tax_amount' || $column == 'base_row_total_incl_tax') {
                        // $value = 'ZMK -'.$value;
                         $value = 'ZMK -' . number_format((float)$value, 2, '.', '');
                    }
                    if ($column == 'qty' || $column == 'tax_percent') {
                        $value = number_format((float)$value, 2, '.', '');
                    }
                } else {
                    if ($column == 'base_price' || $column == 'tax_amount' || $column == 'base_row_total_incl_tax') {
                       // $value = 'ZMK '.$value;
                        $value = 'ZMK ' . number_format((float)$value, 2, '.', '');
                    }
                    if ($column == 'qty' || $column == 'tax_percent') {
                        $value = number_format((float)$value, 2, '.', '');
                    }
                }
                $row[] = $value;
            }
        }
        return $row;
    }
}
