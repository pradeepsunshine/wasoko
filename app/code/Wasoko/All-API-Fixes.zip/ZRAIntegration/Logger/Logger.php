<?php
declare(strict_types=1);

namespace Wasoko\ZRAIntegration\Logger;

class Logger extends \Monolog\Logger
{

}
